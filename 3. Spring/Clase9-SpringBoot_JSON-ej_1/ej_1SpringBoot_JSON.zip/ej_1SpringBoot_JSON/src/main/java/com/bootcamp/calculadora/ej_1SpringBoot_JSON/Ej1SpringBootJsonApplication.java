package com.bootcamp.calculadora.ej_1SpringBoot_JSON;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej1SpringBootJsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ej1SpringBootJsonApplication.class, args);
	}

}
