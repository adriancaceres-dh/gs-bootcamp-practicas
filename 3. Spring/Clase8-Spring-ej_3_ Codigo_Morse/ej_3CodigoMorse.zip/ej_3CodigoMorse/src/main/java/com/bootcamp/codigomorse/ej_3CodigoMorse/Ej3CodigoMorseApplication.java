package com.bootcamp.codigomorse.ej_3CodigoMorse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej3CodigoMorseApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ej3CodigoMorseApplication.class, args);
	}

}
