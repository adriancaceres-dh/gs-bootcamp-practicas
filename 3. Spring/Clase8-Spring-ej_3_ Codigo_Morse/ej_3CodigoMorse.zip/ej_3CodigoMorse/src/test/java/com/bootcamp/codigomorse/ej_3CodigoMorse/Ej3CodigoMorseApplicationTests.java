package com.bootcamp.codigomorse.ej_3CodigoMorse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej3CodigoMorseApplicationTests {

	@Test
	void contextLoads() {
	}

}
