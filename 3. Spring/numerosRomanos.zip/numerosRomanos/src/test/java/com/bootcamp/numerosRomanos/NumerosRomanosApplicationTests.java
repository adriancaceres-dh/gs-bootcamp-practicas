package com.bootcamp.numerosRomanos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NumerosRomanosApplicationTests {

	@Test
	void contextLoads() {
	}

}
