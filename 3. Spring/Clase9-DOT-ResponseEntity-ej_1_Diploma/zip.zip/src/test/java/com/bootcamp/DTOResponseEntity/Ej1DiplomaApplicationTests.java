package com.bootcamp.DTOResponseEntity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej1DiplomaApplicationTests {

	@Test
	void contextLoads() {
	}

}
