package com.bootcamp.DTOResponseEntity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej1DiplomaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ej1DiplomaApplication.class, args);
	}

}
