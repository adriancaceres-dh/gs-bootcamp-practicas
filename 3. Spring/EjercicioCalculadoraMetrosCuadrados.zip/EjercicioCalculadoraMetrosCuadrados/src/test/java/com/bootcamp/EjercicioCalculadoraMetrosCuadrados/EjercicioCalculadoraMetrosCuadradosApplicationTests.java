package com.bootcamp.EjercicioCalculadoraMetrosCuadrados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioCalculadoraMetrosCuadradosApplicationTests {

	@Test
	void contextLoads() {
	}

}
