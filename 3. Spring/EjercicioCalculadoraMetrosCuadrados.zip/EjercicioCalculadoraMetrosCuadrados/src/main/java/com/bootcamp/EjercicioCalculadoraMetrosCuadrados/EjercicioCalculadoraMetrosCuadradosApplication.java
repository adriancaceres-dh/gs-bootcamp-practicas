package com.bootcamp.EjercicioCalculadoraMetrosCuadrados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioCalculadoraMetrosCuadradosApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioCalculadoraMetrosCuadradosApplication.class, args);
	}

}
