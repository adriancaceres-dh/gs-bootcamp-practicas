package com.bootcamp.ejemploSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
