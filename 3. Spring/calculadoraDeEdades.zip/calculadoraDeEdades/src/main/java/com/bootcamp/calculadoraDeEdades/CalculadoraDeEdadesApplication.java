package com.bootcamp.calculadoraDeEdades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculadoraDeEdadesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculadoraDeEdadesApplication.class, args);
	}

}
