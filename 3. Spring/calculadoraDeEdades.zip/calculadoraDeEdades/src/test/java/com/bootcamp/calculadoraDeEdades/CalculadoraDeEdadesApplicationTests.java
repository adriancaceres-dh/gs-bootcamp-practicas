package com.bootcamp.calculadoraDeEdades;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraDeEdadesApplicationTests {

	@Test
	void contextLoads() {
	}

}
