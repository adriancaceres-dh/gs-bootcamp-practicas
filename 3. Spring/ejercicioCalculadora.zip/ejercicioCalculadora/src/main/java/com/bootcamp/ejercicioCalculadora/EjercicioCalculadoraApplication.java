package com.bootcamp.ejercicioCalculadora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioCalculadoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioCalculadoraApplication.class, args);
	}

}
