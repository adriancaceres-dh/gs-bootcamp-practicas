package com.bootcamp.testing.unit.repository;

public class StorehouseRepositoryTest {

}
