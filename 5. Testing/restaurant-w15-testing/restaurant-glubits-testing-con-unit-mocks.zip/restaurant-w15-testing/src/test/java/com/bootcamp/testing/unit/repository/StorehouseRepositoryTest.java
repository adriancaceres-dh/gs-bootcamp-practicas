package com.bootcamp.testing.unit.repository;

// TODO: TESTING UNITARIO SIN MOCKS

public class StorehouseRepositoryTest {

}
