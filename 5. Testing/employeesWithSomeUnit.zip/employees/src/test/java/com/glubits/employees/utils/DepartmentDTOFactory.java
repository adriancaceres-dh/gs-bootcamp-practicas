package com.glubits.employees.utils;

public class DepartmentDTOFactory {
}
