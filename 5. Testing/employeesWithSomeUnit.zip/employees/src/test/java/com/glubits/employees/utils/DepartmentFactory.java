package com.glubits.employees.utils;

public class DepartmentFactory {
}
