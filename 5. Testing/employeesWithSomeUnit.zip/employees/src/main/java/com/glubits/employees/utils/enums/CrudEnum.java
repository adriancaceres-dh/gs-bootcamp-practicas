package com.glubits.employees.utils.enums;

public enum CrudEnum {

    CREATION, DELETATION, UPDATATION, READING
}
