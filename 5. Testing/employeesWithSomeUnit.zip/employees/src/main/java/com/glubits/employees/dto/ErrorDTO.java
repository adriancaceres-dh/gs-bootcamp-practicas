package com.glubits.employees.dto;

public class ErrorDTO {
}
