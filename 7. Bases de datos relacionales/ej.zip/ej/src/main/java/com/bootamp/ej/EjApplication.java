package com.bootamp.ej;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjApplication.class, args);
	}

}
